﻿namespace Calculator
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDisplay = new TextBox();
            panel1 = new Panel();
            btnEnter = new Button();
            btnMulti = new Button();
            btnDivide = new Button();
            btnMinus = new Button();
            btnPlus = new Button();
            btnPeriod = new Button();
            btnZero = new Button();
            btn9 = new Button();
            btn8 = new Button();
            btn7 = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn2 = new Button();
            btn1 = new Button();
            btnHistory = new Button();
            btnClear = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(12, 12);
            txtDisplay.Multiline = true;
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(401, 115);
            txtDisplay.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnEnter);
            panel1.Controls.Add(btnMulti);
            panel1.Controls.Add(btnDivide);
            panel1.Controls.Add(btnMinus);
            panel1.Controls.Add(btnPlus);
            panel1.Controls.Add(btnPeriod);
            panel1.Controls.Add(btnZero);
            panel1.Controls.Add(btn9);
            panel1.Controls.Add(btn8);
            panel1.Controls.Add(btn7);
            panel1.Controls.Add(btn6);
            panel1.Controls.Add(btn5);
            panel1.Controls.Add(btn4);
            panel1.Controls.Add(btn3);
            panel1.Controls.Add(btn2);
            panel1.Controls.Add(btn1);
            panel1.Location = new Point(12, 194);
            panel1.Name = "panel1";
            panel1.Size = new Size(401, 299);
            panel1.TabIndex = 1;
            // 
            // btnEnter
            // 
            btnEnter.Location = new Point(316, 38);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(82, 242);
            btnEnter.TabIndex = 15;
            btnEnter.Text = "Enter";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click;
            // 
            // btnMulti
            // 
            btnMulti.Location = new Point(234, 224);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(71, 56);
            btnMulti.TabIndex = 14;
            btnMulti.Text = "*";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnDivide
            // 
            btnDivide.Location = new Point(234, 162);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(71, 56);
            btnDivide.TabIndex = 13;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnMulti_Click;
            // 
            // btnMinus
            // 
            btnMinus.Location = new Point(234, 100);
            btnMinus.Name = "btnMinus";
            btnMinus.Size = new Size(71, 56);
            btnMinus.TabIndex = 12;
            btnMinus.Text = "-";
            btnMinus.UseVisualStyleBackColor = true;
            btnMinus.Click += btnMulti_Click;
            // 
            // btnPlus
            // 
            btnPlus.Location = new Point(234, 38);
            btnPlus.Name = "btnPlus";
            btnPlus.Size = new Size(71, 56);
            btnPlus.TabIndex = 11;
            btnPlus.Text = "+";
            btnPlus.UseVisualStyleBackColor = true;
            btnPlus.Click += btnMulti_Click;
            // 
            // btnPeriod
            // 
            btnPeriod.Location = new Point(157, 224);
            btnPeriod.Name = "btnPeriod";
            btnPeriod.Size = new Size(71, 56);
            btnPeriod.TabIndex = 10;
            btnPeriod.Text = ".";
            btnPeriod.UseVisualStyleBackColor = true;
            // 
            // btnZero
            // 
            btnZero.Location = new Point(3, 224);
            btnZero.Name = "btnZero";
            btnZero.Size = new Size(148, 56);
            btnZero.TabIndex = 9;
            btnZero.Text = "0";
            btnZero.UseVisualStyleBackColor = true;
            btnZero.Click += btnPeriod_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(157, 38);
            btn9.Name = "btn9";
            btn9.Size = new Size(71, 56);
            btn9.TabIndex = 8;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += btnPeriod_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(80, 38);
            btn8.Name = "btn8";
            btn8.Size = new Size(71, 56);
            btn8.TabIndex = 7;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += btnPeriod_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(3, 38);
            btn7.Name = "btn7";
            btn7.Size = new Size(71, 56);
            btn7.TabIndex = 6;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += btnPeriod_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(157, 100);
            btn6.Name = "btn6";
            btn6.Size = new Size(71, 56);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += btnPeriod_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(80, 100);
            btn5.Name = "btn5";
            btn5.Size = new Size(71, 56);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += btnPeriod_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(3, 100);
            btn4.Name = "btn4";
            btn4.Size = new Size(71, 56);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += btnPeriod_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(157, 162);
            btn3.Name = "btn3";
            btn3.Size = new Size(71, 56);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += btnPeriod_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(80, 162);
            btn2.Name = "btn2";
            btn2.Size = new Size(71, 56);
            btn2.TabIndex = 1;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += btnPeriod_Click;
            // 
            // btn1
            // 
            btn1.Location = new Point(3, 162);
            btn1.Name = "btn1";
            btn1.Size = new Size(71, 56);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btnPeriod_Click;
            // 
            // btnHistory
            // 
            btnHistory.Location = new Point(169, 133);
            btnHistory.Name = "btnHistory";
            btnHistory.Size = new Size(71, 55);
            btnHistory.TabIndex = 2;
            btnHistory.Text = "History";
            btnHistory.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(246, 133);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(167, 55);
            btnClear.TabIndex = 3;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(423, 505);
            Controls.Add(btnClear);
            Controls.Add(btnHistory);
            Controls.Add(panel1);
            Controls.Add(txtDisplay);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Simple Calculator";
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDisplay;
        private Panel panel1;
        private Button btnDivide;
        private Button btnMinus;
        private Button btnPlus;
        private Button btnPeriod;
        private Button btnZero;
        private Button btn9;
        private Button btn8;
        private Button btn7;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button btnMulti;
        private Button btnEnter;
        private Button btnHistory;
        private Button btnClear;
    }
}
