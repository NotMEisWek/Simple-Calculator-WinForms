namespace Calculator
{
    public partial class MainForm : Form
    {
        //Global Variables
        private double FirstOperand = 0; // Stores the first number in the operation
        private string Operation = ""; // Stores the Selected operation ( +, -, *, /)
        private bool isOperationPerformed = false; //Flag to check if an operation button was just pressed
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnPeriod_Click(object sender, EventArgs e)
        {
            Button NumbersButton = (Button)sender;

            //Lets Prevent Multiple Decimal points

            if (NumbersButton.Text == ".")
            {
                if (!txtDisplay.Text.Contains("."))
                {
                    txtDisplay.Text += NumbersButton.Text;
                }
            }
            else
            {
                txtDisplay.Text += NumbersButton.Text;
            }
        }

        //Event Handler for operations
        private void btnMulti_Click(object sender, EventArgs e)
        {
            Button OptButton = (Button)sender;

            if (!string.IsNullOrEmpty(Operation) && !isOperationPerformed)
            {
                btnEnter_Click(sender, e);
            }

            FirstOperand = double.Parse(txtDisplay.Text);
            Operation = OptButton.Text;
            txtDisplay.Text = FirstOperand + " " + Operation + " "; //use to display number and operation in text box
            isOperationPerformed = true;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = "";
            FirstOperand = 0;
            Operation = "";
            isOperationPerformed = false;
        }
        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Operation))
            {
                //No Operation pending, nothing to calculate
                return;
            }

            //Lets separate the string

            string[] parts = txtDisplay.Text.Split(' ');
            if (parts.Length >= 3)
            {
                double SecondOperand = double.Parse(parts[2]); //Get the second number after the operation

                switch (Operation)
                {
                    case "+":
                        txtDisplay.Text = (FirstOperand + SecondOperand).ToString();
                        break;
                    case "-":
                        txtDisplay.Text = (FirstOperand - SecondOperand).ToString();
                        break;
                    case "*":
                        txtDisplay.Text = (FirstOperand * SecondOperand).ToString();
                        break;
                    case "/":
                        if ( SecondOperand != 0)
                        {
                            txtDisplay.Text = (FirstOperand / SecondOperand).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Cannot divide by zero", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtDisplay.Text = "";
                            return;
                        }
                        break;
                    default:
                        break;
                }
                FirstOperand = double.Parse(txtDisplay.Text);
                Operation = "";
                isOperationPerformed = true;
            }
        }

        



    }
}
